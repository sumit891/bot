#!/bin/bash
apt-get update && apt-get install -y ffmpeg
python3 bot.py
